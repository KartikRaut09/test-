# Odin Backend Service: Engine, Agents & Guardrails

> FastAPI backend for **Odin: The Contract War Room** (RAGNAROK Hackathon 2026 — PS 2).

---

## 1. Directory Structure

```
backend/
├── main.py                          # FastAPI application initialization & routes mounting
├── config.py                        # Dynamic configuration (LLM providers, tolerances, paths)
├── requirements.txt                 # Backend dependencies
├── .env.example                     # Environment variables template
│
├── data/
│   └── odin_dev_pack/               # Canonical development dataset mirror
│       ├── clock.json               # Checkpoint timestamps
│       └── bundle/                  # Contracts, company context, ledger, holidays, events
│
├── db/
│   ├── database.py                  # SQLite connection pool & table bootstrap
│   └── models.py                    # Relational schema (contracts, clauses, extractions, rulings, traces)
│
├── engines/                         # PURE PYTHON DETERMINISTIC ENGINES (NO LLM CALLS)
│   ├── manifest_loader.py           # Dynamic document discovery for judge evaluation datasets
│   ├── parser.py                    # Contract chunking into section index (§3.1, line ranges)
│   ├── precedence.py                # Supersession DAG builder (e.g., A3 > A2 §3.1)
│   ├── business_days.py             # Official calendar offset calculator using holidays.csv
│   ├── timeline_engine.py           # Penalty and credit arithmetic calculations
│   ├── event_ingester.py            # Stream parser with corrupted JSON line quarantine
│   └── search.py                    # BM25 lexical retriever across indexed clauses
│
├── guardrails/                      # MULTI-LAYER AGENT INTEGRITY & HALLUCINATION DEFENSE
│   ├── citation_guardrail.py        # Verbatim substring validator against source .txt files
│   ├── arithmetic_guardrail.py      # Math & date auditor (overrides LLM hallucinated figures)
│   ├── schema_guardrail.py          # Strict Pydantic JSON structure validator
│   ├── budget_guardrail.py          # Loop limiters (debates <= 3) & token circuit breaker
│   └── mimir_supervisor.py          # Meta-auditor monitoring inter-agent debate claims
│
├── agents/                          # LLM REASONING AGENTS
│   ├── prompts/                     # SEPARATED PROMPTS DIRECTORY
│   │   ├── loader.py                # Prompt template loader & variable injector
│   │   ├── odin_system.txt          # Orchestrator system prompt
│   │   ├── thor_system.txt          # Clause extraction & verbatim citation rules
│   │   ├── norns_system.txt         # Timeline obligation narrative generator
│   │   ├── loki_system.txt          # Counterparty adversarial counsel
│   │   ├── heimdall_system.txt      # Event-to-clause correlation & noise gate
│   │   ├── tyr_system.txt           # Dispute arbitration & notice letter drafting
│   │   └── mimir_system.txt         # Guardrail supervisor system prompt
│   │
│   ├── base.py                      # Base agent class with prompt loading, retry & logging
│   ├── odin.py                      # Orchestrator agent
│   ├── thor.py                      # Extraction agent
│   ├── norns.py                     # Timeline agent
│   ├── loki.py                      # Adversarial agent
│   ├── heimdall.py                  # Event monitoring agent
│   ├── tyr.py                       # Arbiter agent
│   └── workflow.py                  # LangGraph multi-agent state graph
│
├── schemas/
│   └── messages.py                  # Pydantic schemas for inter-agent communication
│
├── reports/
│   ├── contract_report.py           # Per-contract Markdown report generator
│   ├── company_report.py            # Cross-contract portfolio risk synthesis generator
│   └── templates/                   # Jinja2 report templates
│
├── routes/
│   ├── ingest.py                    # POST /api/ingest (Dynamic judge bundle loading)
│   ├── analysis.py                  # POST /api/analyze (Trigger pipeline run)
│   ├── checkpoint.py                # POST /api/checkpoint (Advance simulated clock)
│   ├── graph.py                     # GET  /api/graph (Nodes and edges for ContractGraph)
│   ├── timeline.py                  # GET  /api/timeline (Active obligations by date)
│   ├── debate.py                    # GET  /api/debate/stream (SSE live debate turns)
│   ├── reports.py                   # GET  /api/reports (Analytical markdown dossiers)
│   ├── alerts.py                    # GET  /api/alerts (Prioritized operational alerts)
│   ├── actions.py                   # GET  /api/actions (Drafted legal notice letters)
│   ├── guardrails.py                # GET  /api/guardrails/audit (Guardrail violation logs)
│   └── traces.py                    # GET  /api/traces (Full LLM trace telemetry)
│
└── tests/
    ├── test_parser.py               # Stable clause IDs test
    ├── test_citation_guardrail.py   # Quote verification test
    ├── test_business_days.py        # Calendar calculation test
    ├── test_timeline_engine.py      # Dollar and date math test
    ├── test_event_ingester.py       # Quarantine test
    ├── test_precedence.py           # Supersession hierarchy test
    └── test_traps.py                # Automated detection of all 14 dataset traps
```

---

## 2. In-Depth Backend Work Division (BE 1 vs. BE 2)

To maximize execution velocity under a 24-hour hackathon constraint, the backend architecture is partitioned cleanly into **two specialized developer roles** with decoupled codebases and explicit data contracts.

```
┌───────────────────────────────────────────────────┬───────────────────────────────────────────────────┐
│            BACKEND DEVELOPER 1 (BE 1)             │            BACKEND DEVELOPER 2 (BE 2)             │
│   "Deterministic Core, Workflow & API Gateway"    │     "Cognitive Agents, Guardrails & Reports"      │
├───────────────────────────────────────────────────┼───────────────────────────────────────────────────┤
│ • engines/manifest_loader.py (Discovery)          │ • schemas/messages.py (Pydantic Message Schemas)  │
│ • engines/parser.py (Clause Indexer)              │ • agents/prompts/*.txt (7 Prompt Template Files)  │
│ • engines/precedence.py (Supersession DAG)        │ • agents/prompts/loader.py (Prompt Loader Engine) │
│ • engines/business_days.py (holidays.csv Math)    │ • agents/base.py (LLM Client, Retry, Logging)     │
│ • engines/timeline_engine.py (Penalties & Dates)  │ • agents/thor.py (Extraction Agent)               │
│ • engines/search.py (BM25 Clause Search)          │ • agents/norns.py (Timeline Narrative Agent)      │
│ • db/database.py & db/models.py (SQLite Tables)   │ • agents/loki.py (Adversarial Legal Agent)        │
│ • agents/odin.py (Master Orchestrator Agent)      │ • agents/heimdall.py (Event Monitor Agent)        │
│ • agents/workflow.py (LangGraph State Machine)    │ • agents/tyr.py (Arbiter & Notice Drafter Agent)  │
│ • routes/ingest.py (Judge Evaluation Ingestion)   │ • engines/event_ingester.py (Quarantine Engine)   │
│ • routes/analysis.py (Pipeline Execution Trigger) │ • guardrails/citation_guardrail.py (Quote Guard)  │
│ • routes/checkpoint.py (Clock Advancement)        │ • guardrails/arithmetic_guardrail.py (Math Guard) │
│ • routes/graph.py (Nodes & Edges for React Flow)  │ • guardrails/schema_guardrail.py (JSON Guard)     │
│ • routes/timeline.py (Active Obligations by Date) │ • guardrails/budget_guardrail.py (Loop Guard)     │
│ • routes/debate.py (Live Server-Sent Events SSE)  │ • guardrails/mimir_supervisor.py (Meta-Auditor)   │
│ • docker-compose.yml & Dockerfile                 │ • reports/contract_report.py (Markdown Generator) │
│ • tests/test_parser.py                            │ • reports/company_report.py (Risk Report Generator│
│ • tests/test_business_days.py                     │ • routes/reports.py, alerts.py, actions.py        │
│ • tests/test_timeline_engine.py                   │ • routes/guardrails.py, traces.py, traps.py       │
│ • tests/test_precedence.py                        │ • tests/test_citation_guardrail.py & traps        │
└───────────────────────────────────────────────────┴───────────────────────────────────────────────────┘
```

---

### 2.1 Backend Dev 1: Core Responsibilities & Deliverables

> **BE 1 Role**: The Foundation, Mathematical Precision & System Orchestration Architect.
> **Motto**: *"Zero LLM hallucinations in the numbers; strict relational persistence and rock-solid state machines."*

#### 1. Ingestion & Deterministic Engines
- **`engines/manifest_loader.py`**: Reads `bundle/manifest.json` dynamically. Discovers all contracts, ledger, and holidays. **Zero hardcoding** of contract filenames or counterparties so judges can drop in their own datasets.
- **`engines/parser.py`**: Chunks `.txt` contracts into canonical clause records (`doc_id`, `section`, `line_range`, `text`). Produces stable IDs (`A1-§3.1`, `B1-§7.2`).
- **`engines/precedence.py`**: Scans contract text for amendment keywords (`"supersedes"`, `"amends"`, `"controls over"`). Dynamically builds a supersession Directed Acyclic Graph (DAG) (e.g., SLA Amendment A3 supersedes SLA A2 §3.1 & §3.2).
- **`engines/business_days.py`**: Ingests `data/holidays.csv` to calculate business-day offsets (e.g., 15-day claim window). Never uses generic OS calendars.
- **`engines/timeline_engine.py`**: Performs pure deterministic arithmetic on SLA credits, penalty percentages, milestone overdue fees, and unrecoverable upstream/downstream leakage.
- **`engines/search.py`**: Implements BM25 lexical search over the indexed clauses for targeted agent retrieval.

#### 2. Relational Database & Persistence
- **`db/database.py` & `db/models.py`**: Initializes SQLite tables (`contracts`, `clauses`, `extractions`, `obligations`, `events`, `risks`, `debates`, `rulings`, `actions`, `traces`, `guardrails_audit`). Implements append-only trace logging.

#### 3. Orchestration & State Machine
- **`agents/odin.py`**: Implements the orchestrator that creates per-contract workstreams and the cross-contract synthesis stream.
- **`agents/workflow.py`**: Builds the LangGraph state machine linking all agents, managing state transitions, conditional debate edges, and checkpoint progressions.

#### 4. Core API Routes & Streaming
- **`routes/ingest.py`**: `POST /api/ingest` for loading judge bundles dynamically.
- **`routes/analysis.py`**: `POST /api/analyze` to trigger the pipeline.
- **`routes/checkpoint.py`**: `POST /api/checkpoint` to advance the simulated clock.
- **`routes/graph.py`**: `GET /api/graph` serving nodes and edges for React Flow.
- **`routes/timeline.py`**: `GET /api/timeline` serving obligations and deadlines for the current clock checkpoint.
- **`routes/debate.py`**: `GET /api/debate/stream` providing real-time Server-Sent Events (SSE) streaming of agent turns.

---

### 2.2 Backend Dev 2: Core Responsibilities & Deliverables

> **BE 2 Role**: Cognitive Reasoning, Prompt Engineering, Guardrails & Report Synthesis Specialist.
> **Motto**: *"Every claim grounded with exact citations; adversarial rigor against counterparty traps; beautiful actionable reports."*

#### 1. Message Contracts & Prompt Architecture
- **`schemas/messages.py`**: Pydantic v2 data models for inter-agent messages (`AgentMessage`, `Citation`, `ExtractionResult`, `DebateTurn`, `RulingPayload`, `NoticeAction`).
- **`agents/prompts/`**: Creates and maintains 7 modular system prompt text files:
  - `odin_system.txt`, `thor_system.txt`, `norns_system.txt`, `loki_system.txt`, `heimdall_system.txt`, `tyr_system.txt`, `mimir_system.txt`.
- **`agents/prompts/loader.py`**: Implements dynamic template loading and parameter formatting.

#### 2. Reasoning Agents
- **`agents/base.py`**: Abstract base agent with exponential backoff retries, provider toggle (`groq` $\leftrightarrow$ `anthropic`), token tracking, and trace logging.
- **`agents/thor.py`**: Clause extraction agent producing structured obligations, penalty triggers, and verbatim text citations.
- **`agents/norns.py`**: Timeline agent synthesizing narrative explanations from `timeline_engine.py` calculations.
- **`agents/loki.py`**: Adversarial agent acting as counterparty counsel, hunting for SLA mismatches, uninsurable liabilities, and notice traps.
- **`agents/heimdall.py`**: Event monitor correlating incoming event logs with contract clauses, filtering operational noise.
- **`agents/tyr.py`**: Judicial arbiter resolving disputes between Loki and Heimdall, drafting signed legal notices (breach letters, credit denials).

#### 3. Multi-Layer Guardrails System
- **`guardrails/citation_guardrail.py`**: Intercepts claims; verifies quotes against `.txt` files with exact substring matching; rejects hallucinations.
- **`guardrails/arithmetic_guardrail.py`**: Verifies that any dollar claim or date interval asserted by an LLM matches the deterministic engine.
- **`guardrails/schema_guardrail.py`**: Validates JSON payloads and enforces `source_tag` (`"sourced"` vs. `"inferred"`).
- **`guardrails/budget_guardrail.py`**: Enforces loop limits ($\le 3$ debate rounds, $\le 2$ clarifications) and circuit-breaks token runaways.
- **`guardrails/mimir_supervisor.py`**: Meta-auditor agent monitoring debate transcripts for procedural compliance.

#### 4. Event Ingestion, Reports & Intelligence Routes
- **`engines/event_ingester.py`**: Parses `.jsonl` files and isolates corrupted lines (e.g. Drop 2 line 8) into quarantine without crashing.
- **`reports/contract_report.py` & `company_report.py`**: Jinja2-based report synthesis generating formatted Markdown dossiers.
- **`routes/reports.py`, `routes/alerts.py`, `routes/actions.py`, `routes/guardrails.py`, `routes/traces.py`, `routes/traps.py`**: Endpoints serving reports, alerts, drafted notices, and audit telemetry.

---

### 2.3 The 14 Dataset Traps: Ownership Matrix

Every trap in the dataset is assigned to a specific developer's subsystem for detection and verification:

| Trap # | Description | Primary Owner | Detection Mechanism |
|:---:|:---|:---:|:---|
| **Trap 1** | SLA claim window silently cut to 15 days in A3 | **BE 1** | `precedence.py` detects A3 overriding A2 §3.2; `timeline_engine.py` flags Apr 15 deadline. |
| **Trap 2** | Upstream 99.5% vs. Downstream 99.9% SLA mismatch | **BE 2** | `loki.py` compares extractions from A2 vs. B1 §3.1; flags 0.4% coverage gap. |
| **Trap 3** | Harbor March outage claim is time-barred (76 days > 45) | **BE 2** | `tyr.py` compares Event E-17 timestamp with B1 §3.5; rules credit void. |
| **Trap 4** | "Consecutive month outages" claim is false (Mar, May) | **BE 1 + BE 2** | BE 1 calendar engine proves April had 100% uptime; BE 2 `tyr.py` refutes claim. |
| **Trap 5** | Vantage outage on May 12 predates contract go-live (May 15) | **BE 2** | `heimdall.py` correlates E-12 with effective date in C1; `tyr.py` rejects penalty. |
| **Trap 6** | Casual email (E-08) is invalid non-renewal notice | **BE 2** | `thor.py` checks notice clause against `company/context.txt`; `tyr.py` invalidates notice. |
| **Trap 7** | Corporate cyber insurance policy lapses June 30 | **BE 2** | `loki.py` scans expiration in `context.txt`; `heimdall.py` raises critical alert. |
| **Trap 8** | Milestone 3 paid Feb 18 before delivery Feb 28 | **BE 1** | `timeline_engine.py` flags ledger payment date preceding deliverable event date. |
| **Trap 9** | Milestone 4 acceptance test pass rate is 98.4% (requires 100%) | **BE 2** | `thor.py` extracts strict 100% test requirement; `tyr.py` flags deemed non-acceptance. |
| **Trap 10**| Event log dated Apr 15 refers to target milestone of Mar 7 | **BE 2** | `event_ingester.py` flags internal timestamp contradiction in milestone log. |
| **Trap 11**| Malformed JSON syntax in Event Drop 2 (Line 8) | **BE 2** | `event_ingester.py` isolates line into quarantine without pipeline failure. |
| **Trap 12**| Maintenance window mismatch (48h/4h vs. 72h/2h) | **BE 2** | `loki.py` compares maintenance covenants in A1 vs. B1; surfaces breach risk. |
| **Trap 13**| Ledger premature overdue tag on invoice with 30-day grace | **BE 1** | `timeline_engine.py` compares invoice date vs. payment terms; flags premature tag. |
| **Trap 14**| Unprorated $40,000 billing for partial September term | **BE 1** | `timeline_engine.py` computes prorated rate; flags overcharge in ledger row 4. |

---

### 2.4 Hour-by-Hour Synchronization Roadmap (BE 1 vs. BE 2)

```
HOUR      BACKEND DEV 1 (Core & Workflow)            BACKEND DEV 2 (Agents & Guardrails)
────────────────────────────────────────────────────────────────────────────────────────────
00 - 01   • Co-author schemas/messages.py            • Co-author schemas/messages.py
          • Setup SQLite db/database.py & models     • Generate mock JSON fixtures for Frontend
────────────────────────────────────────────────────────────────────────────────────────────
01 - 03   • Build engines/manifest_loader.py         • Build engines/event_ingester.py (Quarantine)
          • Build engines/parser.py (Clause Indexer) • Build guardrails/citation_guardrail.py
          • Build engines/precedence.py (DAG)        • Build agents/prompts/loader.py
          [HANDOFF: Deliver clause index to BE 2]    [HANDOFF: Deliver mock JSON to Frontend]
────────────────────────────────────────────────────────────────────────────────────────────
03 - 06   • Build engines/business_days.py           • Build agents/base.py (Retry, Groq/Claude)
          • Build engines/timeline_engine.py (Math)  • Draft prompts: thor, norns, odin
          • Build engines/search.py (BM25)           • Build agents/thor.py (Extraction)
          • Mount routes/graph.py & timeline.py      • Build agents/norns.py (Timeline narrative)
────────────────────────────────────────────────────────────────────────────────────────────
06 - 10   • Build agents/odin.py (Orchestrator)      • Draft prompts: loki, heimdall, tyr
          • Build agents/workflow.py (LangGraph)     • Build agents/loki.py (Adversary)
          • Build routes/debate.py (SSE Stream)      • Build agents/heimdall.py (Events)
          • Mount routes/ingest.py & analysis.py     • Build agents/tyr.py (Arbiter)
          [HANDOFF: SSE stream live for Frontend]    • Build guardrails/budget_guardrail.py
────────────────────────────────────────────────────────────────────────────────────────────
10 - 14   • Connect BE 2 agents into workflow.py     • Implement guardrails/mimir_supervisor.py
          • Run test debate loops (Loki ↔ Heimdall)  • Implement drafted legal notices in tyr.py
          • Debug LangGraph conditional transitions  • Build tests/test_citation_guardrail.py
────────────────────────────────────────────────────────────────────────────────────────────
14 - 18   • Multi-checkpoint pipeline execution      • Build reports/contract_report.py (Jinja2)
          • Test clock advancement (Mar 15, Jun 1)   • Build reports/company_report.py (Jinja2)
          • Mount routes/alerts.py & actions.py      • Mount routes/reports.py & guardrails.py
────────────────────────────────────────────────────────────────────────────────────────────
18 - 22   • Build tests/test_traps.py (14 traps)     • Switch config to Claude 3.5 Sonnet
          • Setup Dockerfile & docker-compose.yml    • Prompt tuning for high-accuracy demo
          • Benchmark response times                 • Mount routes/traps.py & traces.py
────────────────────────────────────────────────────────────────────────────────────────────
22 - 24   • End-to-end full run with judge mock data • End-to-end full run with Claude
          • Clean up logs, remove dead code          • Assist with final presentation script
```

---

## 3. Core Architectural Principles

### 3.1 Separation of Prompts & Agent Code
- **Never embed system prompts in `.py` files.**
- All prompts reside as clean text files in `backend/agents/prompts/*.txt`.
- Agent classes use `backend.agents.prompts.loader.load_prompt("agent_name_system")` to retrieve their system instructions.
- This allows prompt engineering and refining instructions without touching the execution logic.

### 3.2 Python Calculates, LLM Reason
- LLMs are strictly forbidden from performing mental math for penalty credits, business day intervals, or dollar amounts.
- `timeline_engine.py` and `business_days.py` compute exact values; agents provide interpretation, legal strategy, and adversarial debate.

### 3.3 Citation Grounding & Guardrails
- Every obligation, risk, or argument must carry a `Citation` (`doc_id`, `section`, `quote`).
- `CitationGuardrail` verifies that `quote` exists verbatim in the corresponding `.txt` file before any finding is committed to the database.
- Any fabricated or misquoted assertion is rejected and logged in `guardrails_audit`.

### 3.4 Support for Custom Judge Datasets
- **Zero Hardcoded Entities**: The backend does not hardcode contract names ("A1", "B1"), party names ("StratoNode", "Harbor"), or specific dates.
- All documents are discovered via `manifest.json` and `contracts/*.txt`.
- Judges can supply a custom bundle via CLI (`python -m engines.manifest_loader --bundle-path <path> --clock-path <path>`) or API (`POST /api/ingest`).

---

## 4. Setup & Execution

### 4.1 Python Environment

```bash
cd backend

# Create virtual environment
python -m venv venv

# Activate
# Windows:
venv\Scripts\activate
# Linux/Mac:
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt
```

### 4.2 Environment Variables (`.env`)

Create `.env` from `.env.example`:

```env
# LLM Provider: "groq" for development, "anthropic" for production
LLM_PROVIDER=groq
GROQ_API_KEY=your_groq_api_key_here
GROQ_MODEL=llama-3.3-70b-versatile

# Anthropic Configuration
ANTHROPIC_API_KEY=your_anthropic_key_here
ANTHROPIC_MODEL=claude-3-5-sonnet-20241022

# Operational Settings
LLM_TEMPERATURE=0
MAX_DEBATE_ROUNDS=3
MAX_CLARIFICATION_ROUNDS=2
DATA_BUNDLE_PATH=./data/odin_dev_pack/bundle
CLOCK_PATH=./data/odin_dev_pack/clock.json
```

### 4.3 Running the Server

```bash
python main.py
# Server running at http://localhost:8000
# OpenAPI Interactive Docs: http://localhost:8000/docs
```

### 4.4 Running the Test Suite

```bash
pytest tests/ -v
```
