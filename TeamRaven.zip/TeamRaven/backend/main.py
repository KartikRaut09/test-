import logging
from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from backend.config import settings
from backend.db.database import init_db
from backend.engines.manifest_loader import ManifestLoader
from backend.engines.parser import ContractParser
from backend.engines.precedence import PrecedenceEngine
from backend.engines.event_ingester import EventIngester
from backend.engines.ledger_parser import LedgerParser

# Import route modules
from backend.routes.ingest import router as ingest_router
from backend.routes.graph import router as graph_router
from backend.routes.timeline import router as timeline_router
from backend.routes.debate import router as debate_router
from backend.routes.alerts import router as alerts_router
from backend.routes.actions import router as actions_router
from backend.routes.reports import router as reports_router
from backend.routes.traps import router as traps_router
from backend.routes.guardrails import router as guardrails_router
from backend.routes.checkpoint import router as checkpoint_router
from backend.routes.search import router as search_router
from backend.routes.ledger import router as ledger_router
from backend.routes.context import router as context_router

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")
logger = logging.getLogger("odin.main")

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Bootstrap database and ingest canonical development bundle on startup."""
    logger.info("Initializing SQLite database tables...")
    init_db()

    try:
        logger.info(f"Loading bundle from: {settings.DATA_BUNDLE_PATH}")
        manifest = ManifestLoader.load_bundle(settings.DATA_BUNDLE_PATH, settings.CLOCK_PATH)
        
        # Index contracts
        for c in manifest.contracts:
            ContractParser.parse_file(c.doc_id, c.text_path, c.title)
        logger.info(f"Indexed {len(manifest.contracts)} contracts into canonical clause store.")

        # Build precedence DAG
        prec = PrecedenceEngine()
        prec.analyze_all_contracts()
        logger.info("Analyzed supersession hierarchy and built precedence DAG.")

        # Ingest operational events
        if manifest.event_drop1_path:
            e1, q1 = EventIngester.ingest_file(manifest.event_drop1_path, drop_number=1)
            logger.info(f"Ingested {len(e1)} events from Drop 1 (quarantined {len(q1)}).")

        if manifest.event_drop2_path:
            e2, q2 = EventIngester.ingest_file(manifest.event_drop2_path, drop_number=2)
            logger.info(f"Ingested {len(e2)} events from Drop 2 (quarantined {len(q2)}).")

        # Ingest payments ledger
        if manifest.payments_ledger_path:
            entries = LedgerParser.ingest_file(manifest.payments_ledger_path)
            logger.info(f"Ingested {len(entries)} payment transactions from payments_ledger.csv.")

    except Exception as e:
        logger.warning(f"Startup bundle loading encountered warning: {e}")

    yield
    logger.info("Shutting down Odin War Room Backend Gateway.")

app = FastAPI(
    title="Odin: The Contract War Room API",
    description="Autonomous multi-agent contract intelligence and arbitration engine.",
    version="1.0.0",
    lifespan=lifespan
)

# CORS Middleware (supports local React & Next.js development)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Mount all endpoint routers
app.include_router(ingest_router)
app.include_router(graph_router)
app.include_router(timeline_router)
app.include_router(debate_router)
app.include_router(alerts_router)
app.include_router(actions_router)
app.include_router(reports_router)
app.include_router(traps_router)
app.include_router(guardrails_router)
app.include_router(checkpoint_router)
app.include_router(search_router)
app.include_router(ledger_router)
app.include_router(context_router)

@app.get("/")
def root():
    return {
        "system": "Odin Contract War Room API",
        "status": "operational",
        "version": "1.0.0",
        "docs_url": "/docs"
    }

@app.get("/health")
def health():
    return {"status": "healthy"}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("backend.main:app", host="0.0.0.0", port=8000, reload=True)
