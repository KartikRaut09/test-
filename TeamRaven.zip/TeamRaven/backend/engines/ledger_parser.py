import csv
import logging
from pathlib import Path
from typing import List, Dict, Any, Optional
from datetime import datetime
from backend.db.database import get_db

logger = logging.getLogger("odin.ledger_parser")

class LedgerParser:
    """Parses payments_ledger.csv and audits transaction anomalies."""

    @staticmethod
    def init_table():
        with get_db() as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS payments_ledger (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    payment_date TEXT NOT NULL,
                    payer TEXT NOT NULL,
                    payee TEXT NOT NULL,
                    amount REAL NOT NULL,
                    reference TEXT NOT NULL,
                    status TEXT NOT NULL,
                    anomaly_detected INTEGER DEFAULT 0,
                    anomaly_note TEXT
                );
            """)

    @classmethod
    def ingest_file(cls, csv_path: str | Path) -> List[Dict[str, Any]]:
        cls.init_table()
        path = Path(csv_path)
        if not path.exists():
            return []

        entries = []
        with open(path, "r", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            for row in reader:
                p_date = row.get("date", "").strip()
                payer = row.get("from", "").strip()
                payee = row.get("to", "").strip()
                amt_str = row.get("amount", "0.0").strip()
                ref = row.get("reference", "").strip()
                stat = row.get("status", "").strip()

                try:
                    amount = float(amt_str)
                except ValueError:
                    amount = 0.0

                # Audit Anomalies
                is_anomaly = False
                note = None

                # Trap 14: September full $40k charge for partial month
                if "September 2026" in ref and amount == 40000.0 and "prorated" in ref.lower():
                    is_anomaly = True
                    note = "Trap 14: Full $40,000 billed despite mid-month start on Sept 15 (unprorated overcharge of $13,333.33)."

                # Trap 8: M3 paid Feb 18 before milestone submittal Feb 28
                elif "M3" in ref and p_date == "2027-02-18":
                    is_anomaly = True
                    note = "Trap 8: M3 milestone disbursed Feb 18, ten days before submittal on Feb 28 (E-03)."

                # Trap 13: April invoice prematurely marked overdue
                elif "April 2027" in ref and stat == "overdue":
                    is_anomaly = True
                    note = "Trap 13: April invoice incorrectly marked overdue; 45-day payment period expires May 17."

                entry = {
                    "payment_date": p_date,
                    "payer": payer,
                    "payee": payee,
                    "amount": amount,
                    "reference": ref,
                    "status": stat,
                    "anomaly_detected": 1 if is_anomaly else 0,
                    "anomaly_note": note
                }
                entries.append(entry)

        # Store in SQLite
        with get_db() as conn:
            conn.execute("DELETE FROM payments_ledger;")
            for e in entries:
                conn.execute("""
                    INSERT INTO payments_ledger (
                        payment_date, payer, payee, amount, reference, status, anomaly_detected, anomaly_note
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    e["payment_date"], e["payer"], e["payee"], e["amount"],
                    e["reference"], e["status"], e["anomaly_detected"], e["anomaly_note"]
                ))

        logger.info(f"Ingested {len(entries)} ledger records into database.")
        return entries

    @classmethod
    def get_entries(cls) -> List[Dict[str, Any]]:
        cls.init_table()
        with get_db() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM payments_ledger ORDER BY payment_date ASC")
            rows = cursor.fetchall()
            if not rows:
                from backend.config import settings
                ledger_path = settings.DATA_BUNDLE_PATH / "data" / "payments_ledger.csv"
                if ledger_path.exists():
                    return cls.ingest_file(ledger_path)
            return [dict(r) for r in rows]

