from datetime import date
from backend.engines.business_days import BusinessDayCalendar
from backend.schemas.messages import TimelineMilestone, ExposureSummary

class TimelineEngine:
    """Calculates contract deadlines, SLA penalties, and financial exposure deterministically."""

    def __init__(self, calendar: BusinessDayCalendar):
        self.cal = calendar

    def calculate_stratonode_claim_deadline(self, downtime_month: int, downtime_year: int, window_days: int = 15) -> date:
        """Calculates credit claim deadline under A3 §1 (15 days after end of month)."""
        # Determine last day of the month
        if downtime_month == 12:
            end_of_month = date(downtime_year, 12, 31)
        else:
            # First day of next month minus 1 day
            next_month = date(downtime_year, downtime_month + 1, 1)
            end_of_month = self.cal.add_calendar_days(next_month, -1)

        # A3 specifies 15 calendar days
        return self.cal.add_calendar_days(end_of_month, window_days)

    def calculate_harbor_claim_deadline(self, downtime_month: int, downtime_year: int, window_days: int = 45) -> date:
        """Calculates Harbor credit claim deadline under B1 §3.5 (45 days after end of month)."""
        if downtime_month == 12:
            end_of_month = date(downtime_year, 12, 31)
        else:
            next_month = date(downtime_year, downtime_month + 1, 1)
            end_of_month = self.cal.add_calendar_days(next_month, -1)

        return self.cal.add_calendar_days(end_of_month, window_days)

    def is_claim_time_barred(self, request_date: date | str, deadline_date: date | str) -> bool:
        """Returns True if the claim was submitted after the deadline."""
        req_dt = self.cal._to_date(request_date)
        dead_dt = self.cal._to_date(deadline_date)
        return req_dt > dead_dt

    def calculate_sla_recovery_gap(
        self,
        harbor_fee: float = 40000.0,
        stratonode_fee: float = 16000.0,
        harbor_credit_pct: float = 0.15,
        stratonode_credit_pct: float = 0.15
    ) -> dict[str, float]:
        """Calculates downstream liability vs upstream recovery (The $3,600 Gap)."""
        downstream_penalty = harbor_fee * harbor_credit_pct # $6,000
        upstream_recovery = stratonode_fee * stratonode_credit_pct # $2,400
        net_leakage = downstream_penalty - upstream_recovery # $3,600
        
        return {
            "downstream_penalty_owed": downstream_penalty,
            "upstream_recovery_claimable": upstream_recovery,
            "net_unrecoverable_leakage": net_leakage
        }

    def evaluate_checkpoint_exposure(self, checkpoint: str) -> ExposureSummary:
        """Returns a snapshot of active liabilities at a given simulated checkpoint."""
        c_date = self.cal._to_date(checkpoint)

        # Baseline checkpoints:
        # Checkpoint 1: 2027-03-15
        # Checkpoint 2: 2027-06-01
        # Checkpoint 3: 2027-09-15

        summary = ExposureSummary(
            checkpoint_date=checkpoint,
            total_exposure_at_risk=0.0
        )

        if c_date >= date(2027, 3, 15):
            # March outage occurred
            gap = self.calculate_sla_recovery_gap()
            summary.harbor_penalties_owed = gap["downstream_penalty_owed"]
            summary.stratonode_credits_recoverable = gap["upstream_recovery_claimable"]
            summary.net_unrecoverable_leakage = gap["net_unrecoverable_leakage"]
            summary.total_exposure_at_risk += summary.harbor_penalties_owed
            summary.breakdown_by_contract["B1-Harbor"] = summary.harbor_penalties_owed
            summary.breakdown_by_contract["A1-StratoNode"] = -summary.stratonode_credits_recoverable

        if c_date >= date(2027, 6, 1):
            # May outage occurred, plus Milestone 5 delay, plus cyber insurance countdown
            may_gap = self.calculate_sla_recovery_gap()
            summary.harbor_penalties_owed += may_gap["downstream_penalty_owed"]
            summary.stratonode_credits_recoverable += may_gap["upstream_recovery_claimable"]
            summary.net_unrecoverable_leakage += may_gap["net_unrecoverable_leakage"]
            
            # Milestone 5 overdue fees (approx $15,000 milestone with late penalty)
            summary.overdue_milestone_penalties = 7500.0
            summary.total_exposure_at_risk += (may_gap["downstream_penalty_owed"] + summary.overdue_milestone_penalties)
            summary.breakdown_by_contract["D1-Pixelwright"] = summary.overdue_milestone_penalties

        if c_date >= date(2027, 9, 15):
            # Harbor March credit rejected as time-barred (saving $6,000!)
            # But September unprorated overcharge detected
            summary.unprorated_overcharges = 13333.33 # $40k full month vs 20 days
            summary.total_exposure_at_risk += summary.unprorated_overcharges
            summary.breakdown_by_contract["B1-Overcharge"] = summary.unprorated_overcharges

        return summary

    @classmethod
    def calculate_financial_exposure(cls, checkpoint: str = "2027-03-15") -> ExposureSummary:
        """Convenience classmethod calculating financial exposure using default calendar."""
        cal = BusinessDayCalendar()
        engine = cls(cal)
        return engine.evaluate_checkpoint_exposure(checkpoint)

