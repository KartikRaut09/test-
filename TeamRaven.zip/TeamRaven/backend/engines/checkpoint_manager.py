import json
import logging
from datetime import datetime
from pathlib import Path
from typing import Dict, Any, List, Optional
from backend.config import settings
from backend.db.database import get_db
from backend.engines.timeline_engine import TimelineEngine

logger = logging.getLogger("odin.checkpoint_manager")

class CheckpointManager:
    _instance: Optional["CheckpointManager"] = None
    
    def __init__(self, clock_path: Optional[Path] = None):
        self.clock_path = clock_path or settings.CLOCK_PATH
        self.start_date: str = "2027-01-15"
        self.checkpoints: List[str] = ["2027-03-15", "2027-06-01", "2027-09-15"]
        self.current_simulated_date: str = "2027-03-15"
        self.current_checkpoint_idx: int = 0
        self.load_clock()

    @classmethod
    def get_instance(cls) -> "CheckpointManager":
        if cls._instance is None:
            cls._instance = CheckpointManager()
        return cls._instance

    def load_clock(self) -> None:
        """Load clock configuration from file."""
        if self.clock_path and self.clock_path.exists():
            try:
                with open(self.clock_path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    self.start_date = data.get("start_date", self.start_date)
                    self.checkpoints = data.get("checkpoints", self.checkpoints)
                    if self.checkpoints:
                        self.current_simulated_date = self.checkpoints[0]
                        self.current_checkpoint_idx = 0
            except Exception as e:
                logger.error(f"Failed to parse clock.json at {self.clock_path}: {e}")

    def get_clock_state(self) -> Dict[str, Any]:
        """Return the current simulated clock state."""
        return {
            "start_date": self.start_date,
            "checkpoints": self.checkpoints,
            "current_simulated_date": self.current_simulated_date,
            "current_checkpoint_idx": self.current_checkpoint_idx,
            "total_checkpoints": len(self.checkpoints)
        }

    def set_checkpoint(self, checkpoint_date: str) -> Dict[str, Any]:
        """Advance or adjust the current simulated clock to a specific checkpoint date."""
        self.current_simulated_date = checkpoint_date
        if checkpoint_date in self.checkpoints:
            self.current_checkpoint_idx = self.checkpoints.index(checkpoint_date)
        else:
            self.current_checkpoint_idx = -1
        
        # Calculate snapshot state at this checkpoint date
        with get_db() as conn:
            # Count events up to this checkpoint
            cursor = conn.cursor()
            cursor.execute(
                "SELECT COUNT(*) FROM events WHERE timestamp <= ?",
                (self.current_simulated_date,)
            )
            active_events = cursor.fetchone()[0]
            
            # Count quarantined events
            cursor.execute("SELECT COUNT(*) FROM event_quarantine")
            quarantined_events = cursor.fetchone()[0]

        # Calculate exposure via TimelineEngine
        exposure = TimelineEngine.calculate_financial_exposure()

        return {
            "current_simulated_date": self.current_simulated_date,
            "checkpoint_idx": self.current_checkpoint_idx,
            "active_events_count": active_events,
            "quarantined_events_count": quarantined_events,
            "exposure_summary": exposure.model_dump(),
            "status": "synchronized"
        }
