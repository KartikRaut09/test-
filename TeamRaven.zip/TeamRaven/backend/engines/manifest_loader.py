import json
from pathlib import Path
from pydantic import BaseModel, Field

class ContractManifestItem(BaseModel):
    doc_id: str
    title: str
    text_path: Path
    pdf_path: Path | None = None

class BundleManifest(BaseModel):
    bundle_path: Path
    clock_path: Path
    contracts: list[ContractManifestItem] = Field(default_factory=list)
    company_context_path: Path | None = None
    payments_ledger_path: Path | None = None
    holidays_path: Path | None = None
    event_drop1_path: Path | None = None
    event_drop2_path: Path | None = None
    checkpoints: list[str] = Field(default_factory=list)

class ManifestLoader:
    """Dynamically discovers and loads contract bundles without hardcoded IDs."""

    @staticmethod
    def load_bundle(bundle_dir: str | Path, clock_file: str | Path | None = None) -> BundleManifest:
        bundle_path = Path(bundle_dir).resolve()
        if not bundle_path.exists():
            raise FileNotFoundError(f"Bundle directory does not exist: {bundle_path}")

        # Resolve clock.json
        if clock_file:
            clock_path = Path(clock_file).resolve()
        else:
            clock_path = bundle_path.parent / "clock.json"
            if not clock_path.exists():
                clock_path = bundle_path / "clock.json"

        checkpoints = []
        if clock_path.exists():
            try:
                with open(clock_path, "r", encoding="utf-8") as f:
                    clock_data = json.load(f)
                    checkpoints = clock_data.get("checkpoints", [])
            except Exception:
                checkpoints = ["2027-03-15", "2027-06-01", "2027-09-15"]

        manifest_obj = BundleManifest(
            bundle_path=bundle_path,
            clock_path=clock_path,
            checkpoints=checkpoints
        )

        # Company context
        ctx_file = bundle_path / "company" / "context.txt"
        if ctx_file.exists():
            manifest_obj.company_context_path = ctx_file

        # Data files
        ledger_file = bundle_path / "data" / "payments_ledger.csv"
        if ledger_file.exists():
            manifest_obj.payments_ledger_path = ledger_file

        holidays_file = bundle_path / "data" / "holidays.csv"
        if holidays_file.exists():
            manifest_obj.holidays_path = holidays_file

        # Events
        drop1 = bundle_path / "events" / "events_drop1.jsonl"
        if drop1.exists():
            manifest_obj.event_drop1_path = drop1

        drop2 = bundle_path / "events" / "events_drop2.jsonl"
        if drop2.exists():
            manifest_obj.event_drop2_path = drop2

        # Contracts discovery via manifest.json or directory scan
        manifest_json_path = bundle_path / "manifest.json"
        discovered_docs = {}

        if manifest_json_path.exists():
            try:
                with open(manifest_json_path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    # manifest format might be list or dict
                    items = data if isinstance(data, list) else data.get("files", data.get("documents", []))
                    for item in items:
                        if isinstance(item, dict):
                            fname = item.get("path", item.get("file", item.get("filename", "")))
                            title = item.get("title", item.get("description", fname))
                            if fname.endswith(".txt"):
                                doc_id = Path(fname).stem
                                discovered_docs[doc_id] = title
            except Exception:
                pass

        # Also scan contracts/ directory directly to catch any files not in manifest.json
        contracts_dir = bundle_path / "contracts"
        if contracts_dir.exists():
            for txt_file in contracts_dir.glob("*.txt"):
                doc_id = txt_file.stem
                title = discovered_docs.get(doc_id, f"Contract {doc_id}")
                pdf_file = txt_file.with_suffix(".pdf")
                
                manifest_obj.contracts.append(
                    ContractManifestItem(
                        doc_id=doc_id,
                        title=title,
                        text_path=txt_file,
                        pdf_path=pdf_file if pdf_file.exists() else None
                    )
                )

        # Sort contracts alphabetically by doc_id for consistency
        manifest_obj.contracts.sort(key=lambda x: x.doc_id)
        return manifest_obj
