from typing import List
from backend.schemas.messages import (
    ExtractedObligation,
    Citation,
    AdversarialAttack,
    DebateTurn,
    ArbitrationRuling,
    OperationalEvent
)

class MockThor:
    """Proponent agent: extracts obligations and champions Quillhub's legal rights."""

    @staticmethod
    def extract_obligations() -> List[ExtractedObligation]:
        return [
            ExtractedObligation(
                obligation_id="EXT-01",
                doc_id="A3",
                section="§1",
                category="service_level",
                obligor="StratoNode Inc.",
                obligee="Quillhub Inc.",
                summary="SLA credit claim window modified to 15 calendar days post-incident month end.",
                deadline_rule="15 days after end of calendar month in which Downtime occurred",
                financial_formula="25% of Monthly Base Fee ($16,000) = $4,000",
                citation=Citation(
                    doc_id="A3",
                    section="§1",
                    quote="within fifteen (15) days after the end of the calendar month in which the Downtime occurred",
                    verified=True
                ),
                confidence="high",
                source_tag="sourced",
                is_ambiguous=False
            ),
            ExtractedObligation(
                obligation_id="EXT-02",
                doc_id="B1",
                section="§3.5",
                category="service_level",
                obligor="Quillhub Inc.",
                obligee="Harbor Retail Solutions LLC",
                summary="Customer SLA credit claim strict limitation window of 45 calendar days.",
                deadline_rule="45 days following the end of the calendar month",
                financial_formula="15% of Monthly Fee ($40,000) = $6,000 per qualifying incident",
                citation=Citation(
                    doc_id="B1",
                    section="§3.5",
                    quote="within forty-five (45) days after the end of the calendar month in which the Downtime occurred",
                    verified=True
                ),
                confidence="high",
                source_tag="sourced",
                is_ambiguous=False
            )
        ]

class MockLoki:
    """Adversary agent: audits claims, probes loopholes, and mounts adversarial counterparty attacks."""

    @staticmethod
    def generate_attacks(round_number: int) -> List[AdversarialAttack]:
        if round_number == 1:
            return [
                AdversarialAttack(
                    attack_id="ATK-01",
                    category="sla_gap",
                    severity="critical",
                    affected_contracts=["B1"],
                    claim_summary="Harbor asserts two SLA breaches in 6 months triggering Section 8.1 unilateral termination without cure.",
                    counterparty_angle="Harbor claims right to immediate contract termination for consecutive failures.",
                    citations=[
                        Citation(
                            doc_id="B1",
                            section="§8.1",
                            quote="two (2) consecutive calendar months",
                            verified=True
                        )
                    ],
                    confidence="high",
                    source_tag="sourced"
                )
            ]
        return [
            AdversarialAttack(
                attack_id="ATK-02",
                category="sla_gap",
                severity="high",
                affected_contracts=["A3", "A2"],
                claim_summary="Quillhub risk of missing StratoNode 15-day window if claim is delayed beyond June 15.",
                counterparty_angle="StratoNode will reject claim as untimely under Amendment 1.",
                citations=[
                    Citation(
                        doc_id="A3",
                        section="§1",
                        quote="within fifteen (15) days after the end of the calendar month in which the Downtime occurred",
                        verified=True
                    )
                ],
                confidence="high",
                source_tag="sourced"
            )
        ]

class MockHeimdall:
    """Event correlator: cross-references telemetry, emails, and invoices with contract clauses."""

    @staticmethod
    def correlate_events(events: List[OperationalEvent]) -> List[DebateTurn]:
        return [
            DebateTurn(
                turn_id="TURN-02",
                round_number=1,
                speaker="Heimdall",
                speaker_role="event_monitor",
                message_type="counter_evidence",
                content="Notice Event E-17 from Harbor was received on June 15, 2027. Under B1 §3.5, credit requests must be delivered within 45 days of month end. The March claim was submitted 76 days post-incident and is legally time-barred.",
                citations=[
                    Citation(
                        doc_id="B1",
                        section="§3.5",
                        quote="within forty-five (45) days after the end of the calendar month in which the Downtime occurred",
                        verified=True
                    )
                ]
            )
        ]

class MockTyr:
    """Arbitrator agent: weighs claims, applies precedence DAG, and renders final binding rulings."""

    @staticmethod
    def deliver_ruling() -> ArbitrationRuling:
        return ArbitrationRuling(
            ruling_id="RULE-01",
            issue="Harbor Outage Service Credit Claims and Termination Threat",
            verdict="SPLIT",
            rationale=(
                "Harbor's claim for March 2027 ($6,000) is barred by the strict 45-day limitation in B1 §3.5. "
                "The May 2027 claim ($6,000) is valid and approved. "
                "Because April 2027 achieved 99.97% uptime, the outages were non-consecutive, defeating the Section 8.1 termination right."
            ),
            controlling_precedence="B1 §3.5 controls claim timeliness; A3 §1 controls upstream recovery from StratoNode.",
            binding_citations=[
                Citation(
                    doc_id="B1",
                    section="§3.5",
                    quote="within forty-five (45) days after the end of the calendar month in which the Downtime occurred",
                    verified=True
                ),
                Citation(
                    doc_id="A3",
                    section="§1",
                    quote="within fifteen (15) days after the end of the calendar month in which the Downtime occurred",
                    verified=True
                )
            ],
            needs_human_approval=False
        )
