import logging
import uuid
import json
from datetime import datetime
from backend.config import settings
from backend.agents.state import WarRoomState
from backend.agents.mock_agents import MockThor, MockLoki, MockHeimdall, MockTyr
from backend.guardrails.citation_guardrail import CitationGuardrail
from backend.guardrails.budget_guardrail import BudgetGuardrail
from backend.engines.event_ingester import EventIngester
from backend.db.database import get_db

logger = logging.getLogger("odin.workflow")

def load_agents():
    """Dynamically resolves agent implementations: live LLM agents if available and configured, else mock."""
    if not settings.USE_MOCK_AGENTS:
        try:
            from backend.agents.thor import Thor
            from backend.agents.loki import Loki
            from backend.agents.heimdall import Heimdall
            from backend.agents.tyr import Tyr
            logger.info("Loaded live cognitive agents (Thor, Loki, Heimdall, Tyr).")
            return Thor, Loki, Heimdall, Tyr
        except ImportError as e:
            logger.warning(f"Live agents could not be imported ({e}). Falling back to deterministic Mock agents.")
    
    return MockThor, MockLoki, MockHeimdall, MockTyr

class WarRoomPipeline:
    """Orchestrates the multi-agent cognitive loop with deterministic guardrails."""

    def __init__(self, run_id: str | None = None):
        self.run_id = run_id or f"run_{uuid.uuid4().hex[:8]}"

    def execute(self, checkpoint: str = "2027-03-15") -> WarRoomState:
        logger.info(f"Starting War Room pipeline execution: {self.run_id} at checkpoint: {checkpoint}")

        Thor, Loki, Heimdall, Tyr = load_agents()

        # 1. Fetch active events up to this checkpoint
        events = EventIngester.get_events_up_to_checkpoint(checkpoint)

        # 2. Initialize State
        state: WarRoomState = {
            "run_id": self.run_id,
            "checkpoint": checkpoint,
            "contracts": [],
            "events": events,
            "extractions": [],
            "attacks": [],
            "debate_turns": [],
            "ruling": None,
            "actions": [],
            "guardrail_violations": [],
            "round_count": 0,
            "is_concluded": False
        }

        # 3. Node 1: Proponent Extraction (Thor)
        extractions = Thor.extract_obligations()
        # Verify citations with CitationGuardrail
        verified_extractions = []
        for ext in extractions:
            if ext.citation:
                verified = CitationGuardrail.verify_citation(ext.citation)
                ext.citation.verified = verified
            verified_extractions.append(ext)
        state["extractions"] = verified_extractions

        # 4. Debate & Attack Loops with BudgetGuardrail
        budget = BudgetGuardrail(max_debate_rounds=settings.MAX_DEBATE_ROUNDS)

        while state["round_count"] < settings.MAX_DEBATE_ROUNDS:
            state["round_count"] += 1
            current_round = state["round_count"]
            logger.info(f"Entering debate round {current_round}/{settings.MAX_DEBATE_ROUNDS}")

            # Node 2: Adversarial Probe (Loki)
            attacks = Loki.generate_attacks(current_round)
            for atk in attacks:
                for c in atk.citations:
                    c.verified = CitationGuardrail.verify_citation(c)
            state["attacks"].extend(attacks)

            # Node 3: Telemetry Correlator (Heimdall)
            heimdall_turns = Heimdall.correlate_events(state["events"])
            for turn in heimdall_turns:
                for c in turn.citations:
                    c.verified = CitationGuardrail.verify_citation(c)
            state["debate_turns"].extend(heimdall_turns)

            # Record turns in SQLite
            self._persist_debate_turns(state["debate_turns"], checkpoint)

            # Check termination
            if current_round >= settings.MAX_DEBATE_ROUNDS:
                break

        # 5. Node 4: Arbitrator Decision (Tyr)
        ruling = Tyr.deliver_ruling()
        for c in ruling.binding_citations:
            c.verified = CitationGuardrail.verify_citation(c)
        state["ruling"] = ruling
        self._persist_ruling(ruling, checkpoint)

        state["is_concluded"] = True
        logger.info(f"War Room pipeline {self.run_id} completed successfully.")
        return state

    def _persist_debate_turns(self, turns: list, checkpoint: str):
        with get_db() as conn:
            cursor = conn.cursor()
            for t in turns:
                cursor.execute("""
                    INSERT OR REPLACE INTO debates (
                        turn_id, run_id, checkpoint, round_number,
                        speaker, speaker_role, message_type, content, citations_json
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    t.turn_id,
                    self.run_id,
                    checkpoint,
                    t.round_number,
                    t.speaker,
                    t.speaker_role,
                    t.message_type,
                    t.content,
                    json.dumps([c.model_dump() for c in t.citations])
                ))
            conn.commit()

    def _persist_ruling(self, ruling, checkpoint: str):
        with get_db() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT OR REPLACE INTO rulings (
                    ruling_id, run_id, checkpoint, issue, verdict, rationale,
                    controlling_precedence, binding_citations_json, needs_human_approval
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                ruling.ruling_id,
                self.run_id,
                checkpoint,
                ruling.issue,
                ruling.verdict,
                ruling.rationale,
                ruling.controlling_precedence,
                json.dumps([c.model_dump() for c in ruling.binding_citations]),
                1 if ruling.needs_human_approval else 0
            ))
            conn.commit()

def run_war_room_pipeline(checkpoint: str = "2027-03-15") -> WarRoomState:
    pipeline = WarRoomPipeline()
    return pipeline.execute(checkpoint)
