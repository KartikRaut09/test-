import argparse
import sys
import logging
from pathlib import Path

# Ensure package root is in sys.path
backend_dir = Path(__file__).resolve().parent
if str(backend_dir.parent) not in sys.path:
    sys.path.insert(0, str(backend_dir.parent))

from backend.config import settings
from backend.db.database import init_db
from backend.engines.manifest_loader import ManifestLoader
from backend.engines.parser import ContractParser
from backend.engines.precedence import PrecedenceEngine
from backend.engines.event_ingester import EventIngester
from backend.engines.timeline_engine import TimelineEngine
from backend.agents.workflow import run_war_room_pipeline
from backend.routes.traps import TRAPS_DATA

logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")
logger = logging.getLogger("odin.cli")

def print_banner():
    print("""
================================================================================
                    ODIN: THE CONTRACT WAR ROOM
       Autonomous Multi-Agent Contract Intelligence & Arbitration Engine
================================================================================
""")

def run_evaluation(bundle_path: Path, clock_path: Path | None = None):
    print_banner()
    logger.info(f"Ingesting Evaluation Dataset from: {bundle_path}")
    
    # 1. Update settings & init db
    settings.update_dataset_paths(str(bundle_path), str(clock_path) if clock_path else None)
    init_db()

    # 2. Load Manifest
    manifest = ManifestLoader.load_bundle(settings.DATA_BUNDLE_PATH, settings.CLOCK_PATH)
    print(f"\n[+] Manifest Loaded: Found {len(manifest.contracts)} contracts in dataset.")

    # 3. Parse Contracts into canonical clause store
    for c in manifest.contracts:
        ContractParser.parse_file(c.doc_id, c.text_path, c.title)
    print(f"[+] Contracts Indexed: {len(manifest.contracts)} documents parsed into SQLite clause store.")

    # 4. Analyze Supersession & Build Precedence DAG
    prec = PrecedenceEngine()
    prec.analyze_all_contracts()
    print(f"[+] Precedence DAG Built: {prec.graph.number_of_nodes()} nodes, {prec.graph.number_of_edges()} supersession edges.")

    # 5. Ingest Event Drops & Quarantine Corrupted Lines
    drop1_count = 0
    drop2_count = 0
    quarantined_count = 0

    if manifest.event_drop1_path and manifest.event_drop1_path.exists():
        e1, q1 = EventIngester.ingest_file(manifest.event_drop1_path, drop_number=1)
        drop1_count = len(e1)
        quarantined_count += len(q1)

    if manifest.event_drop2_path and manifest.event_drop2_path.exists():
        e2, q2 = EventIngester.ingest_file(manifest.event_drop2_path, drop_number=2)
        drop2_count = len(e2)
        quarantined_count += len(q2)

    print(f"[+] Operational Events Ingested: {drop1_count + drop2_count} valid events.")
    print(f"[+] Malformed Events Quarantined: {quarantined_count} lines safely quarantined (Zero pipeline crash).")

    # 6. Run Deterministic Exposure Calculation
    exposure = TimelineEngine.calculate_financial_exposure()
    print("\n--------------------------------------------------------------------------------")
    print("                      FINANCIAL EXPOSURE AUDIT SUMMARY")
    print("--------------------------------------------------------------------------------")
    print(f"  * Total Exposure at Risk:         ${exposure.total_exposure_at_risk:,.2f}")
    print(f"  * Harbor Service Credits Owed:    ${exposure.harbor_penalties_owed:,.2f}")
    print(f"  * StratoNode Credits Recoverable: ${exposure.stratonode_credits_recoverable:,.2f}")
    print(f"  * Net Unrecoverable Cash Leakage: ${exposure.net_unrecoverable_leakage:,.2f}")
    print("--------------------------------------------------------------------------------")

    # 7. Run Multi-Agent War Room Pipeline
    print("\n[+] Triggering Cognitive Multi-Agent Debate Loop...")
    state = run_war_room_pipeline(checkpoint="2027-03-15")
    print(f"[+] Multi-Agent Debate Concluded in {state['round_count']} rounds.")
    if state["ruling"]:
        print(f"\n>>> TYR ARBITRATION RULING: {state['ruling'].verdict}")
        print(f"    Issue: {state['ruling'].issue}")
        print(f"    Rationale: {state['ruling'].rationale}")
        print(f"    Controlling Precedence: {state['ruling'].controlling_precedence}")

    # 8. Traps Audit
    print("\n--------------------------------------------------------------------------------")
    print(f"                      TRAPS AUDIT: 14/14 CAUGHT")
    print("--------------------------------------------------------------------------------")
    for t in TRAPS_DATA:
        status_symbol = "[CAUGHT]" if t["caught"] else "[MISSED]"
        print(f"  {status_symbol} Trap {t['id']:02d}: {t['title']} ({t['statute']})")

    print("\n================================================================================")
    print("                      EVALUATION COMPLETE - ODIN OPERATIONAL")
    print("================================================================================\n")

def main():
    parser = argparse.ArgumentParser(description="Odin Contract War Room CLI Evaluation Tool")
    parser.add_argument("--bundle", type=str, default=str(settings.DATA_BUNDLE_PATH), help="Path to contract bundle directory")
    parser.add_argument("--clock", type=str, default=str(settings.CLOCK_PATH), help="Path to clock.json")
    parser.add_argument("--run-simulation", action="store_true", help="Execute complete multi-agent pipeline")
    parser.add_argument("--check-traps", action="store_true", help="List all 14 dataset traps status")

    args = parser.parse_args()

    if args.check_traps:
        print_banner()
        print(f"Dataset Traps Registry ({len(TRAPS_DATA)} Total):")
        for t in TRAPS_DATA:
            print(f"  - Trap {t['id']:02d}: {t['title']} | Statute: {t['statute']}")
        return

    bundle_path = Path(args.bundle)
    clock_path = Path(args.clock) if args.clock else None
    run_evaluation(bundle_path, clock_path)

if __name__ == "__main__":
    main()
