from pydantic import BaseModel
from fastapi import APIRouter, HTTPException
from backend.config import settings
from backend.db.database import init_db
from backend.engines.manifest_loader import ManifestLoader
from backend.engines.parser import ContractParser
from backend.engines.precedence import PrecedenceEngine
from backend.engines.event_ingester import EventIngester

router = APIRouter(prefix="/api/ingest", tags=["Ingestion"])

class IngestRequest(BaseModel):
    bundle_path: str
    clock_path: str | None = None

@router.post("")
def ingest_bundle(req: IngestRequest):
    """Dynamically ingests an arbitrary evaluation bundle supplied by judges."""
    try:
        settings.update_dataset_paths(req.bundle_path, req.clock_path)
        init_db()

        # Load manifest
        manifest = ManifestLoader.load_bundle(settings.DATA_BUNDLE_PATH, settings.CLOCK_PATH)
        
        # Parse contracts
        parsed_contracts = []
        for c in manifest.contracts:
            clauses = ContractParser.parse_file(c.doc_id, c.text_path, c.title)
            parsed_contracts.append({"doc_id": c.doc_id, "clauses": len(clauses)})

        # Build precedence DAG
        prec_engine = PrecedenceEngine()
        prec_engine.analyze_all_contracts()

        # Ingest events
        events_count = 0
        quarantine_count = 0
        if manifest.event_drop1_path:
            e1, q1 = EventIngester.ingest_file(manifest.event_drop1_path, drop_number=1)
            events_count += len(e1)
            quarantine_count += len(q1)

        if manifest.event_drop2_path:
            e2, q2 = EventIngester.ingest_file(manifest.event_drop2_path, drop_number=2)
            events_count += len(e2)
            quarantine_count += len(q2)

        return {
            "status": "success",
            "message": "Bundle ingested and indexed successfully",
            "contracts_indexed": len(parsed_contracts),
            "events_ingested": events_count,
            "corrupted_lines_quarantined": quarantine_count,
            "checkpoints": manifest.checkpoints
        }
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))
