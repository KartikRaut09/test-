from fastapi import APIRouter

router = APIRouter(prefix="/api/alerts", tags=["Alerts"])

@router.get("")
def get_alerts():
    """Returns prioritized operational and legal alerts across the portfolio."""
    return [
        {
            "id": "ALT-01",
            "severity": "CRITICAL",
            "title": "Corporate Cyber & Tech E&O Insurance Policy Expiring",
            "contract": "Company Context & Harbor B1 §7",
            "deadline": "2027-06-30",
            "description": "Policy MML-2024-88715 lapses June 30. Uninsured status triggers immediate material breach under Harbor Customer Agreement Section 7.",
            "recommended_action": "Execute Meridian Mutual renewal with Sarah Mitchell before June 25 cutoff."
        },
        {
            "id": "ALT-02",
            "severity": "CRITICAL",
            "title": "StratoNode May Downtime Credit Claim Window Closing",
            "contract": "StratoNode A3 §1",
            "deadline": "2027-06-15",
            "description": "May downtime of 505 minutes eligible for 15% credit ($2,400). A3 §1 cuts notice period to 15 days post month-end.",
            "recommended_action": "Submit formal written credit request to Jordan Hale at StratoNode Notice Address before June 15."
        },
        {
            "id": "ALT-03",
            "severity": "WARNING",
            "title": "Harbor Retail Time-Barred Credit Denial Required",
            "contract": "Harbor Retail B1 §3.5",
            "deadline": "Immediate",
            "description": "Harbor requested $6,000 credit for March 3 incident on June 15 (76 days elapsed vs 45-day window).",
            "recommended_action": "Issue formal legal denial letter for March credit citing Section 3.5 while approving May credit ($6,000)."
        },
        {
            "id": "ALT-04",
            "severity": "WARNING",
            "title": "Pixelwright Milestone M5 Overdue — Penalty Accrual Active",
            "contract": "Pixelwright D1 §4",
            "deadline": "2027-06-01",
            "description": "Milestone M5 is 62 days past target date. Late penalty accrued: $7,500.",
            "recommended_action": "Issue formal delay notice requesting revised delivery schedule or penalty withholding."
        },
        {
            "id": "ALT-05",
            "severity": "INFO",
            "title": "Vantage Logistics Go-Live Target Passed — Service Active",
            "contract": "Vantage Logistics C1",
            "deadline": "2027-05-15",
            "description": "Route Optimizer platform successfully transitioned to live production for Vantage Logistics. SLA monitoring active.",
            "recommended_action": "Ensure monthly invoice for $18,500 is scheduled for July billing cycle."
        }
    ]
