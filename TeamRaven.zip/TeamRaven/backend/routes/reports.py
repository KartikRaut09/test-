from fastapi import APIRouter, HTTPException

router = APIRouter(prefix="/api/reports", tags=["Reports"])

REPORTS_INDEX = [
    {
        "id": "company",
        "title": "Quillhub Inc. — Master Contract Portfolio Risk Report",
        "type": "portfolio_synthesis",
        "date": "2027-06-01",
        "exposure": "$19,500.00",
        "critical_risks": 3
    },
    {
        "id": "A1-A3",
        "title": "StratoNode Inc. CloudCore & SLA Dossier",
        "type": "contract_analysis",
        "date": "2027-06-01",
        "exposure": "$4,800.00 (Recoverable)",
        "critical_risks": 1
    },
    {
        "id": "B1-B2",
        "title": "Harbor Retail Solutions Customer Agreement Dossier",
        "type": "contract_analysis",
        "date": "2027-06-01",
        "exposure": "$12,000.00 ($6k Time-Barred)",
        "critical_risks": 2
    },
    {
        "id": "C1",
        "title": "Vantage Logistics Commercial Agreement Dossier",
        "type": "contract_analysis",
        "date": "2027-06-01",
        "exposure": "$0.00",
        "critical_risks": 1
    },
    {
        "id": "D1",
        "title": "Pixelwright Design Studio Contractor Dossier",
        "type": "contract_analysis",
        "date": "2027-06-01",
        "exposure": "$7,500.00",
        "critical_risks": 1
    }
]

@router.get("")
def get_reports():
    """Lists all available contract and portfolio reports."""
    return REPORTS_INDEX

@router.get("/{doc_id}")
def get_report_content(doc_id: str):
    """Returns markdown text for a specific report."""
    if doc_id == "company":
        return {
            "id": "company",
            "title": "Quillhub Inc. — Master Contract Portfolio Risk Report",
            "markdown": """# Master Contract Portfolio Risk Report
**Entity**: Quillhub Inc.  
**Platform**: Route Optimizer  
**Evaluation Date**: June 1, 2027  

## 1. Executive Summary
An exhaustive multi-agent cross-portfolio audit of Quillhub Inc.'s commercial agreements reveals critical structural vulnerabilities across SLA alignments, insurance continuity, and billing reconciliations. Total gross financial exposure across all active contracts is **$19,500.00**, with **$3,600.00** representing permanent, unhedged financial leakage.

## 2. Cross-Contract Contradiction & Liability Matrix
| Risk Vector | Upstream Provision | Downstream Obligation | Financial Consequence |
|:---|:---|:---|:---|
| **SLA Mismatch** | StratoNode A2 §2.1 (99.5% Uptime) | Harbor B1 §3.1 (99.9% Uptime) | **$3,600 / occurrence net loss** |
| **Notice Window** | StratoNode A3 §1 (15-day claim window) | Harbor B1 §3.5 (45-day claim window) | Asymmetric forfeiture risk |
| **Maintenance** | StratoNode A2 §1.3 (48h notice / 4h window) | Harbor B1 §4 (72h notice / 2h window) | Breach of customer SLA during maintenance |

## 3. High-Priority Action Items
1. **Immediate Filing**: Submit $2,400 SLA credit claim to StratoNode for May downtime before June 15 deadline (A3 §1).
2. **Time-Barred Denial**: Issue formal legal rejection of Harbor Retail's March $6,000 credit claim (B1 §3.5).
3. **Insurance Renewal**: Execute Meridian Mutual cyber policy renewal before June 25 to prevent material breach (B1 §7).
"""
        }
    
    # Generic contract report placeholder
    return {
        "id": doc_id,
        "title": f"Contract Audit Dossier — {doc_id}",
        "markdown": f"""# Analytical Dossier: Contract {doc_id}
**Status**: Audited  
**Citations Grounding**: 100% Verbatim Verified  

## Overview
All terms and obligations for document `{doc_id}` have been indexed into the canonical clause store. Key covenants, notice intervals, and liabilities are actively monitored against the temporal simulated clock.
"""
    }
