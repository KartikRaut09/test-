from fastapi import APIRouter, HTTPException

router = APIRouter(prefix="/api/actions", tags=["Actions"])

ACTIONS_STORE = [
    {
        "action_id": "ACT-01",
        "action_type": "credit_claim",
        "target_party": "StratoNode Inc.",
        "target_address": "8500 Cascade Boulevard, Suite 200, Portland, OR 97204 (Attn: Legal Department)",
        "title": "Demand for SLA Service Credit — May 2027 Unavailability",
        "subject_line": "Formal Service Credit Request: QH-STRATO-2026-001 / SLA AMD No. 1",
        "letter_body": """StratoNode Inc.
Attn: Legal Department
8500 Cascade Boulevard, Suite 200
Portland, OR 97204
Email: legal@stratonode.com

Re: Service Credit Request under SLA Amendment No. 1 (QH-STRATO-2026-AMD1)

Dear StratoNode Legal Team,

Pursuant to Section 1 of Amendment No. 1 to the Service Level Agreement (replacing Section 3.2 of Document ID QH-STRATO-2026-SLA), Quillhub Inc. hereby submits this formal written request for a Service Credit arising from the CloudCore infrastructure downtime that occurred on May 1–2, 2027.

1. Incident Details:
   - Start Time: May 1, 2027, 22:15 UTC
   - End Time: May 2, 2027, 06:40 UTC
   - Total Downtime: 505 minutes
   - Affected Region: us-west-2 (CloudCore Compute & Storage)
   - Calculated Monthly Uptime Percentage: 98.87% (44,640 min total - 505 min downtime) / 44,640 min

2. Service Credit Calculation:
   Pursuant to Section 2 of Amendment No. 1, because the Monthly Uptime Percentage fell between 95.0% and 99.0%, Quillhub is entitled to a Service Credit of 15% of the Monthly Fee:
   - Monthly Base Fee: $16,000.00
   - Service Credit Claimed: 15% × $16,000.00 = $2,400.00

This written request is delivered within fifteen (15) days after the end of the calendar month in which the downtime occurred, in strict compliance with Section 3.2 of the Agreement. Please confirm receipt and apply this $2,400.00 credit to Quillhub's next monthly invoice.

Sincerely,

Dana Kowalski
Director of Engineering, Quillhub Inc.""",
        "binding_clauses": [
            {"doc_id": "A3", "section": "§1", "quote": "within fifteen (15) days after the end of the calendar month in which the Downtime occurred", "verified": True},
            {"doc_id": "A3", "section": "§2", "quote": "95.0% to < 99.0% | 15% of Monthly Fee", "verified": True}
        ],
        "deadline_to_send": "2027-06-15",
        "status": "drafted",
        "needs_human_approval": True
    },
    {
        "action_id": "ACT-02",
        "action_type": "credit_denial",
        "target_party": "Harbor Retail Solutions LLC",
        "target_address": "400 Harborfront Plaza, Suite 1200, Seattle, WA 98101 (Attn: Legal Department)",
        "title": "Partial SLA Credit Approval & Time-Barred Denial Notice",
        "subject_line": "Response to Service Credit Request (QH-HARBOR-2026-001)",
        "letter_body": """Harbor Retail Group LLC
Attn: Legal Department & Nora Chen, SVP Supply Chain
400 Harborfront Plaza, Suite 1200
Seattle, WA 98101

Re: Service Credit Request Response — Agreement QH-HARBOR-2026-001

Dear Nora,

Quillhub Inc. has reviewed your formal Service Credit Request dated June 15, 2027. We respond to your claims as follows:

1. May 2027 Incident: APPROVED ($6,000.00)
   Quillhub confirms that platform availability during May 2027 fell below the 99.9% target due to an upstream hosting disruption. Pursuant to Section 3.5, a 15% credit ($6,000.00) has been approved and will be credited against Invoice QH-INV-2027-07-HR.

2. March 2027 Incident: DENIED (Time-Barred)
   Your request for a $6,000.00 credit for the March 3, 2027 incident is respectfully denied as time-barred. Section 3.5 of the Agreement expressly requires:
   "Customer must submit a written credit request within forty-five (45) calendar days following the end of the calendar month in which the Downtime occurred."
   The deadline for March 2027 credit submissions was May 15, 2027. Your request was received on June 15, 2027 (76 days post-month end), rendering the claim untimely and extinguished.

3. Correction of Consecutive Breach Assertion:
   Your letter asserts that the SLA target was missed in two consecutive months. This assertion is factually incorrect. Platform uptime for April 2027 was 99.97% (exceeding the 99.9% commitment). Consequently, Section 8.1 termination rights have not been triggered.

Sincerely,

Dana Kowalski
Director of Engineering, Quillhub Inc.""",
        "binding_clauses": [
            {"doc_id": "B1", "section": "§3.5", "quote": "within forty-five (45) calendar days following the end of the calendar month in which the Downtime occurred", "verified": True},
            {"doc_id": "B1", "section": "§8.1", "quote": "two or more consecutive calendar months", "verified": True}
        ],
        "deadline_to_send": "2027-06-20",
        "status": "drafted",
        "needs_human_approval": True
    }
]

from backend.engines.action_dispatcher import ActionDispatcher

ActionDispatcher.sync_initial_actions(ACTIONS_STORE)

@router.get("")
def get_actions():
    """Returns drafted formal legal notices with cryptographic signatures."""
    result = []
    for action in ACTIONS_STORE:
        sig = ActionDispatcher.compute_signature(action)
        item = dict(action)
        item["digital_sha256_seal"] = sig
        result.append(item)
    return result

@router.post("/{action_id}/approve")
def approve_action(action_id: str):
    """Marks an action as approved for dispatch."""
    for action in ACTIONS_STORE:
        if action["action_id"] == action_id:
            action["status"] = "approved"
            action["needs_human_approval"] = False
            ActionDispatcher.approve_action(action_id)
            return {"status": "success", "action": action}
    raise HTTPException(status_code=404, detail="Action not found")

@router.post("/{action_id}/dispatch")
def dispatch_action(action_id: str):
    """Dispatches the legal action and generates a verified SHA-256 digital seal."""
    for action in ACTIONS_STORE:
        if action["action_id"] == action_id:
            action["status"] = "dispatched"
            action["needs_human_approval"] = False
            dispatch_rec = ActionDispatcher.dispatch_action(action_id)
            action["digital_sha256_seal"] = dispatch_rec["digital_sha256_seal"]
            return {"status": "success", "dispatch_record": dispatch_rec, "action": action}
    raise HTTPException(status_code=404, detail="Action not found")
