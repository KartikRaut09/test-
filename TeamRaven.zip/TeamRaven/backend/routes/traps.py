from fastapi import APIRouter

router = APIRouter(prefix="/api/traps", tags=["Traps"])

TRAPS_DATA = [
    {
        "id": 1,
        "title": "A3 Silently Cuts SLA Claim Window to 15 Days",
        "category": "Supersession Trap",
        "caught": True,
        "evidence": "A3 §1 explicitly deletes and replaces A2 §3.2, cutting claim window from 30 days to 15 days.",
        "statute": "A3 §1",
        "consequence": "Claim for March outage was due April 15, not April 30."
    },
    {
        "id": 2,
        "title": "Upstream 99.5% vs. Downstream 99.9% SLA Mismatch",
        "category": "Liability Trap",
        "caught": True,
        "evidence": "StratoNode A2 §2.1 commits to 99.5% uptime; Harbor B1 §3.1 requires 99.9%.",
        "statute": "A2 §2.1 vs. B1 §3.1",
        "consequence": "0.4% monthly uptime gap is entirely unhedged and uninsurable."
    },
    {
        "id": 3,
        "title": "Harbor March Credit Claim Is Time-Barred (76 Days)",
        "category": "Temporal Trap",
        "caught": True,
        "evidence": "Harbor claimed March outage on June 15 (E-17). B1 §3.5 imposes strict 45-day window from month end.",
        "statute": "B1 §3.5",
        "consequence": "Quillhub legally saves $6,000 by formally denying the claim."
    },
    {
        "id": 4,
        "title": "E-17 'Consecutive Months' Outage Assertion is False",
        "category": "Evidentiary Trap",
        "caught": True,
        "evidence": "Harbor claimed consecutive misses in March and May. April uptime was 99.97% (E-07).",
        "statute": "B1 §8.1",
        "consequence": "Harbor's right to terminate for consecutive failures is blocked."
    },
    {
        "id": 5,
        "title": "Vantage May Outage Predates Go-Live Date",
        "category": "Temporal Trap",
        "caught": True,
        "evidence": "Vantage May 12 outage (E-12) occurred before effective go-live on May 15 (C1).",
        "statute": "C1 Cover Page",
        "consequence": "No service credits or penalties apply to Vantage during staging."
    },
    {
        "id": 6,
        "title": "Casual Email (E-08) Fails Formal Non-Renewal Standard",
        "category": "Notice Trap",
        "caught": True,
        "evidence": "Derek Sung's email was sent to wrong recipient, lacked required formal legal notice, and predated allowable term.",
        "statute": "company/context.txt & C1 Notice Clause",
        "consequence": "Email is legally void; agreement auto-renews unless formal notice follows."
    },
    {
        "id": 7,
        "title": "Cyber Insurance Policy Lapses June 30",
        "category": "Default Trap",
        "caught": True,
        "evidence": "Meridian Mutual policy expires June 30 (E-16). Harbor B1 §7 makes continuous coverage mandatory.",
        "statute": "B1 §7 & E-16",
        "consequence": "Lapse causes immediate material breach with 5-day cure window."
    },
    {
        "id": 8,
        "title": "Milestone 3 Paid Feb 18 Before Deliverable Submittal",
        "category": "Accounting Trap",
        "caught": True,
        "evidence": "Ledger records $15,000 M3 payment on Feb 18; submittal occurred Feb 28 (E-03).",
        "statute": "payments_ledger.csv vs. E-03",
        "consequence": "Audit flag: Premature payment disbursed prior to acceptance inspection."
    },
    {
        "id": 9,
        "title": "Milestone 4 Shows 98.4% Pass Rate (Requires 100%)",
        "category": "Acceptance Trap",
        "caught": True,
        "evidence": "E-11 logs 98.4% unit test pass rate; D1 Exhibit A requires 100% test pass for milestone acceptance.",
        "statute": "D1 Exhibit A",
        "consequence": "Deliverable is deemed unaccepted; milestone fee withheld until cured."
    },
    {
        "id": 10,
        "title": "Internal Timestamp Contradiction in Milestone Log",
        "category": "Data Hygiene",
        "caught": True,
        "evidence": "Phone call log dated Apr 15 refers to target delivery of March 7 instead of April.",
        "statute": "E-10 Log",
        "consequence": "Informal oral modification flagged as non-binding."
    },
    {
        "id": 11,
        "title": "Malformed JSON Line Quarantined in Event Drop 2",
        "category": "Resilience Trap",
        "caught": True,
        "evidence": "Line 8 of events_drop2.jsonl contains raw unparseable text. Quarantined without crash.",
        "statute": "event_quarantine table",
        "consequence": "Zero pipeline interruption; corrupted line logged for audit."
    },
    {
        "id": 12,
        "title": "Maintenance Window Incompatibility (48h/4h vs. 72h/2h)",
        "category": "Operational Mismatch",
        "caught": True,
        "evidence": "StratoNode requires 48h notice for up to 4h maintenance; Harbor allows only 2h maintenance with 72h notice.",
        "statute": "A2 §1.3 vs. B1 Maintenance Clause",
        "consequence": "Routine upstream maintenance will cause Quillhub to breach downstream customer SLA."
    },
    {
        "id": 13,
        "title": "Accounting Ledger Premature Overdue Tag on Invoice",
        "category": "Ledger Trap",
        "caught": True,
        "evidence": "April Harbor invoice due May 17 (45 days) marked overdue in ledger row 21.",
        "statute": "payments_ledger.csv vs. E-09",
        "consequence": "False overdue flag in ledger corrected against actual contract credit terms."
    },
    {
        "id": 14,
        "title": "September Ledger Shows Full $40,000 for Partial Month",
        "category": "Billing Trap",
        "caught": True,
        "evidence": "Ledger row 4 records full $40,000 charge for September despite mid-month start date.",
        "statute": "payments_ledger.csv Row 4",
        "consequence": "Overcharge of $13,333.33 flagged for customer reconciliation."
    }
]

@router.get("")
def get_traps():
    """Returns status and evidence for all 14 dataset traps."""
    return {
        "total_traps": len(TRAPS_DATA),
        "caught_count": sum(1 for t in TRAPS_DATA if t["caught"]),
        "traps": TRAPS_DATA
    }
