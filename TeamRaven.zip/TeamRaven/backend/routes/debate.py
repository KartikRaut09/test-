import asyncio
import json
from datetime import datetime
from fastapi import APIRouter
from fastapi.responses import StreamingResponse

router = APIRouter(prefix="/api/debate", tags=["Debate"])

# Scripted debate messages for real-time demonstration
SCRIPTED_DEBATE = [
    {
        "round_number": 1,
        "speaker": "Loki",
        "speaker_role": "adversary",
        "message_type": "attack",
        "content": "Harbor Retail demands $12,000 in SLA service credits for downtime in March (190 min) and May (505 min). Under Section 8.1 of B1, two service level failures within a 6-month period grants Harbor the unilateral right to terminate for material cause without penalty.",
        "citations": [{"doc_id": "B1", "section": "§8.1", "quote": "Customer may terminate this Agreement immediately upon written notice if Provider fails to meet the Uptime Target in two or more calendar months within any six-month period", "verified": True}]
    },
    {
        "round_number": 1,
        "speaker": "Heimdall",
        "speaker_role": "event_monitor",
        "message_type": "counter_evidence",
        "content": "Notice Event E-17 from Harbor was received on June 15, 2027. Under B1 §3.5, credit requests must be delivered within 45 days of the month-end. The March outage credit request was submitted 76 days post-incident. The March credit claim is time-barred.",
        "citations": [{"doc_id": "B1", "section": "§3.5", "quote": "Customer must submit a written credit request within forty-five (45) calendar days following the end of the calendar month", "verified": True}]
    },
    {
        "round_number": 2,
        "speaker": "Loki",
        "speaker_role": "adversary",
        "message_type": "attack",
        "content": "Even if March credits are time-barred, Harbor explicitly claimed in E-17 that March and May constitute 'consecutive month failures'. If interpreted consecutively, Section 8.1 termination is triggered immediately.",
        "citations": [{"doc_id": "B1", "section": "§8.1", "quote": "two or more consecutive calendar months", "verified": True}]
    },
    {
        "round_number": 2,
        "speaker": "Heimdall",
        "speaker_role": "event_monitor",
        "message_type": "counter_evidence",
        "content": "Fact check against Event E-07 and monitoring telemetry: In April 2027, Route Optimizer achieved 99.97% uptime with only 12 downtime minutes, exceeding the 99.9% target. March and May are separated by an operational April—they are not consecutive.",
        "citations": [{"doc_id": "B1", "section": "§3.1", "quote": "Uptime Target of 99.9%", "verified": True}]
    },
    {
        "round_number": 3,
        "speaker": "Tyr",
        "speaker_role": "arbiter",
        "message_type": "ruling",
        "content": "RULING: Harbor's assertion of consecutive SLA breaches is FALSE. The March credit request of $6,000 is legally time-barred under B1 §3.5. Harbor is entitled only to the May credit of $6,000. Quillhub must immediately file a credit claim of $2,400 with StratoNode under A3 §1 (deadline: June 15). Net unrecoverable loss is capped at $3,600.",
        "citations": [
            {"doc_id": "B1", "section": "§3.5", "quote": "forty-five (45) calendar days", "verified": True},
            {"doc_id": "A3", "section": "§1", "quote": "within fifteen (15) days after the end of the calendar month", "verified": True}
        ]
    }
]

@router.get("/stream")
async def stream_debate():
    """Server-Sent Events endpoint streaming real-time multi-agent debate turns using native StreamingResponse."""
    async def event_generator():
        for turn in SCRIPTED_DEBATE:
            turn_data = {
                **turn,
                "timestamp": datetime.utcnow().isoformat()
            }
            yield f"event: debate_turn\ndata: {json.dumps(turn_data)}\n\n"
            # Simulate real-time inter-agent thinking latency
            await asyncio.sleep(1.5)

    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive"
        }
    )
