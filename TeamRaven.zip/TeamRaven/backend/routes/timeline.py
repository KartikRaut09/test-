from fastapi import APIRouter, Query
from backend.config import settings
from backend.engines.manifest_loader import ManifestLoader
from backend.engines.business_days import BusinessDayCalendar
from backend.engines.timeline_engine import TimelineEngine
from backend.engines.event_ingester import EventIngester

router = APIRouter(prefix="/api/timeline", tags=["Timeline"])

@router.get("")
def get_timeline(clock: str = Query(default="2027-03-15", description="Simulated checkpoint ISO date")):
    manifest = ManifestLoader.load_bundle(settings.DATA_BUNDLE_PATH, settings.CLOCK_PATH)
    cal = BusinessDayCalendar(manifest.holidays_path)
    engine = TimelineEngine(cal)

    # Calculate exposure snapshot at this checkpoint
    exposure = engine.evaluate_checkpoint_exposure(clock)

    # Get events filtered by checkpoint
    events = EventIngester.get_events_up_to_checkpoint(clock)

    # Standard milestones
    milestones = [
        {
            "id": "M3-review",
            "title": "Pixelwright Milestone M3 Acceptance Review",
            "date": "2027-03-12",
            "contract": "D1",
            "status": "completed" if clock >= "2027-03-12" else "pending",
            "notes": "10 business days from Feb 28 submission (accepted by silence)"
        },
        {
            "id": "StratoNode-Mar-Claim",
            "title": "StratoNode March Downtime Credit Claim Deadline (15 Days)",
            "date": "2027-04-15",
            "contract": "A3",
            "status": "completed" if clock >= "2027-04-15" else "active",
            "notes": "A3 §1 cuts claim window to 15 days; credit: $2,400"
        },
        {
            "id": "Harbor-Mar-Claim",
            "title": "Harbor March Outage Claim Deadline (45 Days)",
            "date": "2027-05-15",
            "contract": "B1",
            "status": "time_barred" if clock >= "2027-05-15" else "pending",
            "notes": "Harbor claim submitted on June 15 was legally void"
        },
        {
            "id": "StratoNode-May-Claim",
            "title": "StratoNode May Downtime Credit Claim Deadline (15 Days)",
            "date": "2027-06-15",
            "contract": "A3",
            "status": "completed" if clock >= "2027-06-15" else "active",
            "notes": "May downtime 505 minutes; claimable credit: $2,400"
        },
        {
            "id": "Cyber-Insurance-Expiry",
            "title": "Corporate Cyber & Tech E&O Insurance Expiration",
            "date": "2027-06-30",
            "contract": "Context",
            "status": "critical" if clock >= "2027-06-01" else "upcoming",
            "notes": "Lapse causes material breach under Harbor B1 §7"
        },
        {
            "id": "Vantage-Live",
            "title": "Vantage Logistics Go-Live Target Date",
            "date": "2027-05-15",
            "contract": "C1",
            "status": "completed" if clock >= "2027-05-15" else "pending",
            "notes": "SLA commitments only apply post go-live"
        }
    ]

    return {
        "clock_position": clock,
        "checkpoints": manifest.checkpoints,
        "exposure": exposure.model_dump(),
        "milestones": milestones,
        "active_events_count": len(events)
    }
