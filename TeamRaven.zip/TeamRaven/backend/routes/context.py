from fastapi import APIRouter
from pathlib import Path
from typing import Dict, Any
from backend.config import settings
from backend.engines.manifest_loader import ManifestLoader

router = APIRouter(prefix="/api/context", tags=["Company Context"])

@router.get("")
def get_company_context() -> Dict[str, Any]:
    """Returns the company corporate context, key personnel, authorized signatories, and insurance policies."""
    manifest = ManifestLoader.load_bundle(settings.DATA_BUNDLE_PATH, settings.CLOCK_PATH)
    raw_text = ""
    if manifest.company_context_path and manifest.company_context_path.exists():
        with open(manifest.company_context_path, "r", encoding="utf-8") as f:
            raw_text = f.read()

    return {
        "company_name": "Quillhub Inc.",
        "jurisdiction": "Delaware, United States",
        "principal_office": "1200 Innovation Drive, Suite 400, Austin, TX 78701",
        "business": "Route Optimizer Cloud Logistics Platform",
        "hosting_provider": "StratoNode Inc.",
        "authorized_signatories": [
            {"name": "Priya Chandrasekaran", "role": "CEO", "email": "priya.c@quillhub.io"},
            {"name": "Marcus Ellison", "role": "VP of Legal & Compliance", "email": "marcus.e@quillhub.io"}
        ],
        "legal_notice_address": "Quillhub Inc., Attn: Legal Department, 1200 Innovation Drive, Suite 400, Austin, TX 78701 (legal-notices@quillhub.io)",
        "insurance_policies": [
            {
                "type": "Commercial General Liability",
                "insurer": "Meridian Mutual Insurance Co.",
                "policy_no": "MML-2024-88714",
                "coverage": "$2,000,000 per occurrence",
                "expiry": "2027-06-30",
                "status": "active"
            },
            {
                "type": "Cyber Liability & Technology E&O",
                "insurer": "Meridian Mutual Insurance Co.",
                "policy_no": "MML-2024-88715",
                "coverage": "$3,000,000 per claim",
                "expiry": "2027-06-30",
                "status": "expiring_soon",
                "alert": "Lapse causes immediate material breach under Harbor B1 §7.1"
            }
        ],
        "raw_text": raw_text
    }
