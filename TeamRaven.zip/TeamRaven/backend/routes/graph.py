from fastapi import APIRouter
from backend.db.database import get_connection

router = APIRouter(prefix="/api/graph", tags=["Graph"])

@router.get("")
def get_contract_graph():
    """Returns nodes and edges formatted for @xyflow/react (React Flow)."""
    with get_connection() as conn:
        contracts = conn.execute("SELECT doc_id, title FROM contracts").fetchall()
        rules = conn.execute("SELECT superior_doc_id, subordinate_doc_id, rule_text FROM precedence_rules").fetchall()

    nodes = []
    edges = []

    # Center node: Quillhub Platform
    nodes.append({
        "id": "quillhub",
        "type": "input",
        "data": {"label": "Quillhub Inc. (Route Optimizer)", "role": "hub", "party": "Quillhub"},
        "position": {"x": 300, "y": 200}
    })

    # Fixed positions for clean layout
    positions = {
        "A1": {"x": 100, "y": 50},
        "A2": {"x": -80, "y": 140},
        "A3": {"x": -100, "y": 280},
        "STD": {"x": 300, "y": -40},
        "B1": {"x": 580, "y": 60},
        "B2": {"x": 760, "y": 180},
        "C1": {"x": 150, "y": 380},
        "D1": {"x": 480, "y": 380},
    }

    for c in contracts:
        doc_id = c["doc_id"]
        pos = positions.get(doc_id, {"x": 200, "y": 200})
        nodes.append({
            "id": doc_id,
            "data": {
                "label": f"[{doc_id}] {c['title']}",
                "doc_id": doc_id,
                "title": c["title"]
            },
            "position": pos
        })

        # Connect contract to Quillhub
        if doc_id in ("A1", "B1", "C1", "D1"):
            edges.append({
                "id": f"edge-qh-{doc_id}",
                "source": "quillhub",
                "target": doc_id,
                "label": "governs",
                "animated": True,
                "style": {"stroke": "#4f8fff"}
            })

    # Add supersession / incorporation edges from precedence_rules
    for r in rules:
        sup = r["superior_doc_id"]
        sub = r["subordinate_doc_id"]
        edges.append({
            "id": f"edge-rule-{sup}-{sub}",
            "source": sup,
            "target": sub,
            "label": "supersedes" if "replace" in r["rule_text"].lower() or "amend" in r["rule_text"].lower() else "controls over",
            "style": {"stroke": "#ffaa00", "strokeDasharray": "5,5"}
        })

    return {"nodes": nodes, "edges": edges}
